# tfg/app/crud.py

from sqlalchemy.orm import Session
from . import models, schemas
import logging

logging.basicConfig(level=logging.INFO)

def get_user(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.id == user_id).first()

def get_user_by_email(db: Session, email: str):
    logging.info(f"Buscando usuario en DB con email: {email}")
    result = db.query(models.User).filter(models.User.email == email).first()
    logging.info(f"Resultado de búsqueda: {result}")
    return result

def create_user(db: Session, user: schemas.UserCreate):
    try:
        logging.info(f"Intentando crear usuario con email: {user.email}")
        
        # Verifica si el usuario ya existe antes de crear
        existing_user = get_user_by_email(db, user.email)
        if existing_user:
            logging.warning(f"El email ya está registrado: {user.email}")
            return None
        
        # Crea el usuario sin cifrar la contraseña
        db_user = models.User(email=user.email, hashed_password=user.password)
        
        db.add(db_user)
        db.flush()  # Asegura que se ejecute la sentencia SQL
        db.commit()
        db.refresh(db_user)
        
        logging.info(f"Usuario creado exitosamente: {db_user.email}")
        return db_user
    except Exception as e:
        logging.error(f"Error al crear usuario: {str(e)}")
        db.rollback()
        return None
