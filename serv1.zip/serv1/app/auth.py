# tfg/app/routes/auth.py
from fastapi import APIRouter, Depends, HTTPException, status, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from jose import JWTError, jwt
from .  import schemas, crud, database  # Importaciones corregidas
from fastapi.templating import Jinja2Templates
import logging

logging.basicConfig(level=logging.INFO)


router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

SECRET_KEY = "casacasa"  # Clave secreta
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Verificación de contraseña en texto plano
def verify_password(plain_password, stored_password):
    return plain_password == stored_password  # Comparación directa

# Autenticación de usuario
def authenticate_user(db: Session, email: str, password: str):
    logging.info(f"Buscando usuario con email: {email}")
    user = crud.get_user_by_email(db, email)
    logging.info(f"Usuario encontrado: {user}")

    if not user:
        logging.warning(f"Usuario no encontrado: {email}")
        return None

    # Si no estás usando bcrypt, compara la contraseña directamente
    if user.hashed_password != password:
        logging.warning(f"Contraseña incorrecta para usuario: {email}")
        return None

    logging.info(f"Usuario autenticado: {email}")
    return user

# Crear Token JWT
def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# Obtener Usuario Actual
def get_current_user(db: Session = Depends(database.get_db), token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = crud.get_user_by_email(db, email)
    if user is None:
        raise credentials_exception
    return user

# Endpoint para generar el Token
@router.post("/token", response_model=schemas.Token)
def login_for_access_token(
    db: Session = Depends(database.get_db),
    form_data: OAuth2PasswordRequestForm = Depends()
):
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

# Mostrar Página de Login
@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

# Autenticación de Login
@router.post("/login", response_class=JSONResponse)
async def login(
    db: Session = Depends(database.get_db),
    email: str = Form(...),
    password: str = Form(...)
):
    user = authenticate_user(db, email, password)
    if not user:
        return JSONResponse(content={"error": "Incorrect username or password"}, status_code=400)
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    return JSONResponse(content={
        "access_token": access_token,
        "token_type": "bearer"
    })

# Mostrar Página de Registro
@router.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

# Registro de Usuario
@router.post("/register", response_class=HTMLResponse)
async def register(
    request: Request,
    db: Session = Depends(database.get_db),
    email: str = Form(...),
    password: str = Form(...)
):
    logging.info(f"Intentando registrar usuario con email: {email}")

    # Verifica si el usuario ya existe
    db_user = crud.get_user_by_email(db, email=email)
    if db_user:
        logging.warning(f"El email ya está registrado: {email}")
        return templates.TemplateResponse("register.html", {
            "request": request,
            "error": "Email already registered"
        })

    # Intenta crear el usuario
    user_create = schemas.UserCreate(email=email, password=password)
    new_user = crud.create_user(db=db, user=user_create)
    
    if new_user:
        logging.info(f"Usuario registrado exitosamente: {new_user.email}")
        return templates.TemplateResponse("login.html", {
            "request": request,
            "success": "Registration successful! Please log in."
        })
    else:
        logging.error(f"Error al registrar usuario: {email}")
        return templates.TemplateResponse("register.html", {
            "request": request,
            "error": "Registration failed. Please try again."
        })
