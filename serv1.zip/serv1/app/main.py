# tfg/app/main.py
from fastapi import FastAPI, Depends, Request
from starlette.middleware.sessions import SessionMiddleware
from starlette.responses import RedirectResponse
from .database import engine, Base
from app import auth  # auth.py ahora está en app/
from app.routes import users, items  # users.py e items.py siguen en routes/
from app.auth import get_current_user  # Importación correcta

Base.metadata.create_all(bind=engine)

app = FastAPI()

app.add_middleware(SessionMiddleware, secret_key="your_secret_key")

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(items.router)

@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    if request.url.path not in ["/login", "/register", "/token"] and "access_token" not in request.cookies:
        return RedirectResponse(url="/login")
    response = await call_next(request)
    return response

