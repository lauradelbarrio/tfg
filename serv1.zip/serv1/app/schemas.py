from pydantic import BaseModel, EmailStr, validator
from typing import Optional

class ItemBase(BaseModel):
    name: str
    description: Optional[str] = None

class ItemCreate(ItemBase):
    pass

class Item(ItemBase):
    id: int
    owner_id: int

    class Config:
        from_attributes = True

class UserBase(BaseModel):
    email: EmailStr

    # Eliminar el validador específico de dominios
    # @validator('email')
    # def validate_email_domain(cls, v):
    #     allowed_domains = ["@gmail.com", "@algo.es"]
    #     if not any(v.endswith(domain) for domain in allowed_domains):
    #         raise ValueError('Email domain must be one of @algo.com or @algo.es')
    #     return v

class UserCreate(UserBase):
    password: str

class User(UserBase):
    id: int
    is_active: bool

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: Optional[str] = None

