# tfg/app/models.py
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from .database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True)  # Añadir longitud al VARCHAR
    hashed_password = Column(String(255))  # Añadir longitud al VARCHAR
    is_active = Column(Boolean, default=True)

class Item(Base):
    __tablename__ = "items"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), index=True)  # Añadir longitud al VARCHAR
    description = Column(String(255), index=True)  # Añadir longitud al VARCHAR
    owner_id = Column(Integer, ForeignKey("users.id"))
    owner = relationship("User")

