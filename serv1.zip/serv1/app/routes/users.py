from fastapi import APIRouter, Depends, HTTPException, Request, Form
from sqlalchemy.orm import Session
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from .. import schemas, crud, database

router = APIRouter()

templates = Jinja2Templates(directory="app/templates")

@router.post("/users/", response_model=schemas.User)
def create_user(user: schemas.UserCreate, db: Session = Depends(database.get_db)):
    # Verifica si el usuario ya existe
    db_user = crud.get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    # Crea el usuario
    return crud.create_user(db=db, user=user)

@router.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@router.post("/register")
async def register(
    request: Request,
    db: Session = Depends(database.get_db),
    email: str = Form(None),
    password: str = Form(None),
):
    """
    Este endpoint maneja tanto solicitudes JSON como formularios.
    """
    # Si el contenido es JSON, extraer los datos del cuerpo
    if request.headers.get("content-type") == "application/json":
        data = await request.json()
        email = data.get("email")
        password = data.get("password")

    # Validar campos requeridos
    if not email or not password:
        raise HTTPException(status_code=400, detail="Email and password are required")

    # Crear el usuario
    try:
        user_create = schemas.UserCreate(email=email, password=password)
        create_user(user=user_create, db=db)
        if request.headers.get("content-type") == "application/json":
            return JSONResponse(content={"message": "User registered successfully"})
        else:
            return templates.TemplateResponse(
                "register.html", {"request": request, "message": "Registration successful!"}
            )
    except HTTPException as e:
        if request.headers.get("content-type") == "application/json":
            raise e
        else:
            return templates.TemplateResponse("register.html", {"request": request, "error": e.detail})
