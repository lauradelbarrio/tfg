CREATE TABLE users (
    id INT NOT NULL AUTO_INCREMENT,
    email VARCHAR(255),
    hashed_password VARCHAR(255),
    is_active TINYINT(1),
    PRIMARY KEY (id)
);

CREATE TABLE items (
    id INT NOT NULL AUTO_INCREMENT,
    title VARCHAR(255),
    description TEXT,
    owner_id INT,
    PRIMARY KEY (id),
    FOREIGN KEY(owner_id) REFERENCES users(id)
);

CREATE UNIQUE INDEX ix_users_email ON users(email);
CREATE INDEX ix_users_id ON users(id);
CREATE INDEX ix_items_description ON items(description);
CREATE INDEX ix_items_id ON items(id);
CREATE INDEX ix_items_title ON items(title);

