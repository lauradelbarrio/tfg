import { useEffect, useMemo, useState } from "react";
import {
  Container,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Divider,
  Box,
} from "@mui/material";
import BarChartIcon from "@mui/icons-material/BarChart";
import {
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  BarChart,
  Cell,
  LabelList,
} from "recharts";

interface Redirection {
  incoming_url: string;
  redirect_url: string;
  access_count: number;
  created_by?: string | null;
  first_access_at?: string | null;  // ISO del primer acceso
  days_remaining?: number | null;   // calculado por el backend
}

const API = "http://34.175.150.36:8000/api/redirections";

function App() {
  const [data, setData] = useState<Redirection[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      setLoading(true);
      const res = await fetch(API, { cache: "no-store" });
      const json = (await res.json()) as Redirection[];
      setData(json);
    } catch (e) {
      console.error("Error al cargar datos:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 10000);
    return () => clearInterval(id);
  }, []);

  // Gráfico 1: por link (barras horizontales, usuario dentro de barra)
  const maxAccess = useMemo(
    () => Math.max(1, ...data.map((d) => d.access_count)),
    [data]
  );

  // Gráfico 2: por usuario (sumatorio)
  const byUser = useMemo(() => {
    const map = new Map<string, number>();
    for (const row of data) {
      const user = (row.created_by ?? "").trim();
      if (!user) continue;
      map.set(user, (map.get(user) ?? 0) + (row.access_count ?? 0));
    }
    const arr = Array.from(map.entries()).map(([user, total]) => ({
      user,
      total_access: total,
    }));
    arr.sort((a, b) => b.total_access - a.total_access);
    return arr;
  }, [data]);

  const maxAccessUsers = useMemo(
    () => Math.max(1, ...byUser.map((d) => d.total_access)),
    [byUser]
  );

  const fmtDateTime = (iso?: string | null) =>
    iso ? new Date(iso).toLocaleString() : "—";

  return (
    /* ⬇️ Layout a pantalla completa con flex column */
    <Box sx={{ display: "flex", flexDirection: "column", height: "100vh", minHeight: 0 }}>
      {/* Header */}
      <Box
        component="header"
        sx={{
          p: 2,
          borderBottom: 1,
          borderColor: "divider",
          flexShrink: 0,
        }}
      >
        <Typography variant="h4" display="flex" alignItems="center">
          <BarChartIcon sx={{ mr: 1 }} /> Estadísticas de Redirecciones
        </Typography>
        <Typography variant="body2" sx={{ color: "text.secondary", mt: 1 }}>
          Fuente: <code>{API}</code>
        </Typography>
      </Box>

      {/* Main scrollable area */}
      <Box component="main" sx={{ flex: 1, minHeight: 0, overflow: "auto" }}>
        {/* Usamos el ancho completo del viewport */}
        <Container maxWidth={false} sx={{ py: 2 }}>
          {/* Tabla con altura máxima relativa al viewport:
              - No se corta
              - Hace scroll interno si hay muchas filas */}
          <Paper elevation={1} sx={{ mb: 4, overflow: "hidden" }}>
            <TableContainer
              sx={{
                /* Altura máxima: ocupa ~65% del viewport
                   (ajústalo a tu gusto: 60–70 suele ir bien) */
                maxHeight: "65vh",
                overflow: "auto",
              }}
            >
              <Table stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell><strong>Usuario (creador)</strong></TableCell>
                    <TableCell><strong>Fecha primer acceso</strong></TableCell>
                    <TableCell><strong>Días restantes</strong></TableCell>
                    <TableCell><strong>URL Entrante</strong></TableCell>
                    <TableCell><strong>URL Redireccionada</strong></TableCell>
                    <TableCell align="right"><strong>Accesos</strong></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data.length > 0 ? (
                    data.map((row) => (
                      <TableRow key={row.incoming_url} hover>
                        <TableCell>{row.created_by ?? "—"}</TableCell>
                        <TableCell>{fmtDateTime(row.first_access_at)}</TableCell>
                        <TableCell>
                          {row.days_remaining ?? "—"}
                        </TableCell>
                        <TableCell
                          sx={{
                            maxWidth: 480,
                            whiteSpace: "nowrap",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                          }}
                          title={row.incoming_url}
                        >
                          <a href={row.incoming_url} target="_blank" rel="noreferrer">
                            {row.incoming_url}
                          </a>
                        </TableCell>
                        <TableCell
                          sx={{
                            maxWidth: 480,
                            whiteSpace: "nowrap",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                          }}
                          title={row.redirect_url}
                        >
                          <a href={row.redirect_url} target="_blank" rel="noreferrer">
                            {row.redirect_url}
                          </a>
                        </TableCell>
                        <TableCell align="right">{row.access_count}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6}>
                        {loading ? "Cargando..." : "No hay redirecciones registradas."}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>

          {/* Gráfico 1: por link (usuario dentro de la barra, a la izquierda) */}
          {data.length > 0 && (
            <Box sx={{ mb: 6 }}>
              <Typography variant="h6" sx={{ mb: 1 }}>
                Accesos por Link
              </Typography>
              <ResponsiveContainer width="100%" height={420}>
                <BarChart
                  data={data}
                  layout="vertical"
                  margin={{ top: 20, right: 50, left: 160, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" allowDecimals={false} />
                  <YAxis
                    type="category"
                    dataKey="redirect_url"
                    width={360}
                    tick={{ fontSize: 12 }}
                  />
                  <Tooltip />
                  <Bar dataKey="access_count" isAnimationActive={false}>
                    <LabelList
                      dataKey="created_by"
                      position="insideLeft"
                      formatter={(v: any) => (v && String(v).trim() ? v : "—")}
                      style={{ fill: "#fff", fontSize: 12, fontWeight: 600 }}
                    />
                    {data.map((entry, index) => {
                      const opacity = 0.3 + 0.7 * (entry.access_count / maxAccess);
                      return <Cell key={`cell-link-${index}`} fill={`rgba(63, 81, 181, ${opacity})`} />;
                    })}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </Box>
          )}

          <Divider sx={{ my: 3 }} />

          {/* Gráfico 2: por usuario (vertical) */}
          {byUser.length > 0 ? (
            <Box sx={{ mt: 3 }}>
              <Typography variant="h6" sx={{ mb: 1 }}>
                Accesos Totales por Usuario
              </Typography>
              <ResponsiveContainer width="100%" height={420}>
                <BarChart data={byUser} margin={{ top: 20, right: 50, left: 20, bottom: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis
                    dataKey="user"
                    tick={{ fontSize: 12 }}
                    interval={0}
                    angle={-20}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Bar dataKey="total_access" isAnimationActive={false}>
                    <LabelList position="top" />
                    {byUser.map((entry, index) => {
                      const opacity = 0.3 + 0.7 * (entry.total_access / maxAccessUsers);
                      return <Cell key={`cell-user-${index}`} fill={`rgba(25, 118, 210, ${opacity})`} />;
                    })}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </Box>
          ) : (
            <Typography variant="body2" sx={{ color: "text.secondary", mt: 2 }}>
              Aún no hay usuarios con enlaces registrados.
            </Typography>
          )}
        </Container>
      </Box>
    </Box>
  );
}

export default App;
