from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import (
    create_engine, Column, String, Table, MetaData, Integer, DateTime, func,
    select, insert, update, text
)
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import inspect
import uvicorn
import urllib.parse
import sys
from datetime import datetime, timedelta, timezone
from typing import Optional  # << compat Python 3.8

# ------------------ DB ------------------
DATABASE_URL = "mysql+pymysql://laura:casacasa@localhost/tfg"
engine = create_engine(DATABASE_URL)
metadata = MetaData()
SessionLocal = sessionmaker(bind=engine)

# Definición (puede incluir columnas aún no presentes físicamente)
redirections = Table(
    'redirections', metadata,
    Column('incoming_url', String(1000), primary_key=True),
    Column('redirect_url', String(1000)),
    Column('access_count', Integer, default=0),
    Column('created_by', String(255), nullable=True),
    Column('first_access_at', DateTime, nullable=True),  # fecha primer acceso
)

redirection_logs = Table(
    'redirection_logs', metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('incoming_url', String(1000)),
    Column('access_time', DateTime, default=func.now())
)

# Crea tablas si no existen
metadata.create_all(engine)

def ensure_column(table: str, col_name: str, col_def_sql: str):
    """Añade la columna si no existe (compatible)."""
    with engine.connect() as conn:
        insp = inspect(conn)
        existing = {c["name"] for c in insp.get_columns(table)}
        if col_name not in existing:
            conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_def_sql}"))
            conn.commit()

# Migraciones ligeras
try:
    ensure_column("redirections", "created_by", "VARCHAR(255) NULL")
    ensure_column("redirections", "first_access_at", "DATETIME NULL")
except Exception as e:
    print(f"[LOG] Aviso migración columnas: {e}")
    sys.stdout.flush()

# ------------------ APP ------------------
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def log(msg: str):
    print(f"[LOG] {msg}")
    sys.stdout.flush()

ZARA_URL = "https://www.zara.com/"  # Destino al caducar
TTL_DAYS = 30                       # Vigencia: 30 días desde primer acceso

def to_aware_utc(dt: Optional[datetime]) -> Optional[datetime]:
    """Convierte un datetime a aware UTC. Si es None, devuelve None."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        # MySQL DATETIME suele venir naive -> asumimos UTC
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)

@app.get("/silence/redirect.html/{encoded_url:path}")
async def redirect_and_store(encoded_url: str, request: Request):
    incoming_url = str(request.url)               # incluye ?u=...
    redirect_url = urllib.parse.unquote(encoded_url)
    user_email = request.query_params.get("u")
    now = datetime.now(timezone.utc)              # aware UTC

    log(f"Recibido: {incoming_url}")
    log(f"URL destino: {redirect_url}")
    if user_email:
        log(f"Usuario (u): {user_email}")

    session = SessionLocal()
    try:
        row = session.execute(
            select(
                redirections.c.redirect_url,
                redirections.c.first_access_at
            ).where(redirections.c.incoming_url == incoming_url)
        ).fetchone()

        if row:
            stored_redirect = row[0]
            first_access_at = to_aware_utc(row[1])  # normalizamos a aware UTC

            # Si nunca se accedió, marcamos primer acceso ahora
            if first_access_at is None:
                session.execute(
                    update(redirections)
                    .where(redirections.c.incoming_url == incoming_url)
                    .values(first_access_at=now)
                )
                first_access_at = now

            # ¿Caducado?
            expires_at = first_access_at + timedelta(days=TTL_DAYS)
            if now >= expires_at:
                target = ZARA_URL
                log(f"Enlace CADUCADO (primer acceso: {first_access_at}). Redirigiendo a: {target}")
            else:
                target = stored_redirect
                log(f"URL ya registrada y vigente. Redirigiendo a: {target}")

            # Log de acceso + incremento
            session.execute(insert(redirection_logs).values(incoming_url=incoming_url))
            session.execute(
                update(redirections)
                .where(redirections.c.incoming_url == incoming_url)
                .values(access_count=redirections.c.access_count + 1)
            )
            session.commit()
            return RedirectResponse(url=target)

        # ---- No existe: insertamos y primer acceso ahora ----
        log("URL no registrada, insertando nueva...")
        values = {
            "incoming_url": incoming_url,
            "redirect_url": redirect_url,
            "access_count": 1,
            "created_by": user_email,
            "first_access_at": now,   # primer acceso = ahora
        }
        session.execute(insert(redirections).values(**values))
        session.execute(insert(redirection_logs).values(incoming_url=incoming_url))
        session.commit()
        log("Inserción exitosa.")
        # Al ser primer acceso, nunca caducado
        return RedirectResponse(url=redirect_url)

    except SQLAlchemyError as e:
        log(f"Error de base de datos: {e}")
        session.rollback()
        raise HTTPException(status_code=500, detail="Database error")
    finally:
        session.close()

@app.get("/api/redirections")
async def get_redirections():
    session = SessionLocal()
    try:
        # Seleccionamos sólo columnas existentes
        with engine.connect() as conn:
            cols = {c["name"] for c in inspect(conn).get_columns("redirections")}

        sel = [
            redirections.c.incoming_url,
            redirections.c.redirect_url,
            redirections.c.access_count,
        ]
        if "created_by" in cols:
            sel.append(redirections.c.created_by)
        if "first_access_at" in cols:
            sel.append(redirections.c.first_access_at)

        rows = session.execute(select(*sel)).fetchall()

        now = datetime.now(timezone.utc)
        out = []
        for r in rows:
            m = r._mapping
            first_access_at = to_aware_utc(m.get("first_access_at"))

            if first_access_at:
                expires_at = first_access_at + timedelta(days=TTL_DAYS)
                delta = expires_at - now
                # days: parte entera de días; no negativo
                days_remaining = max(0, delta.days)
            else:
                days_remaining = None

            out.append({
                "incoming_url": m.get("incoming_url"),
                "redirect_url": m.get("redirect_url"),
                "access_count": m.get("access_count"),
                "created_by": m.get("created_by", None),
                "first_access_at": first_access_at.isoformat() if first_access_at else None,
                "days_remaining": days_remaining,
            })
        return out

    except SQLAlchemyError as e:
        raise HTTPException(status_code=500, detail=f"Error en la base de datos: {e}")
    finally:
        session.close()

if __name__ == "__main__":
    uvicorn.run("redirection:app", host="0.0.0.0", port=8000, reload=True)
