package com.example.tfg3

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NfcAdapter
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import java.nio.charset.Charset

// Clase que maneja la recepción de eventos NFC
class NfcReceiver : BroadcastReceiver() {
    // Método que se llama cuando se recibe un intent
    override fun onReceive(context: Context, intent: Intent) {
        // Verifica si la acción del intent es de tipo "NDEF_DISCOVERED" (descubrimiento de un mensaje NDEF)
        if (NfcAdapter.ACTION_NDEF_DISCOVERED == intent.action) {
            // Obtiene los mensajes NDEF del intent
            val rawMessages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES, NdefMessage::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES) as Array<NdefMessage>?
            }
            // Si hay mensajes, procesa el primero
            if (rawMessages != null && rawMessages.isNotEmpty()) {
                val ndefRecord = rawMessages[0].records[0]
                val payload = ndefRecord.payload
                val textEncoding = if ((payload[0].toInt() and 128) == 0) "UTF-8" else "UTF-16"
                val languageCodeLength = payload[0].toInt() and 63
                val text = String(payload, languageCodeLength + 1, payload.size - languageCodeLength - 1, Charset.forName(textEncoding))
                Log.i("NFC", "Contenido leído de la etiqueta NFC: $text")
                showNotification(context, text)
            }
        }
    }

    // Muestra una notificación con el contenido del NFC
    private fun showNotification(context: Context, text: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "nfc_channel_id"
        val channelName = "Canal NFC"

        // Configura el canal de notificaciones si es Android O o superior
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "Canal para notificaciones NFC"
            channel.enableLights(true)
            channel.lightColor = Color.BLUE
            notificationManager.createNotificationChannel(channel)
        }

        // Crea un intent para abrir el enlace o la aplicación principal
        val intent = if (text.startsWith("http://") || text.startsWith("https://")) {
            Intent(Intent.ACTION_VIEW, Uri.parse(text))
        } else {
            Intent(context, MainActivity::class.java).apply {
                putExtra("nfc_content", text)
            }
        }
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        // Construye la notificación
        val notification = NotificationCompat.Builder(context, channelId)
            .setContentTitle("Etiqueta NFC detectada")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(1, notification)
    }
}
