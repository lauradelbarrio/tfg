package com.example.tfg3.models;

public class LoginResponse {
    private String access_token;

    public String getAccessToken() {
        return access_token;
    }
}