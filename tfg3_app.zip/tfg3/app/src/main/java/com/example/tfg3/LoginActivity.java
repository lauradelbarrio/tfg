package com.example.tfg3;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg3.models.LoginResponse;
import com.example.tfg3.network.ApiService;
import com.example.tfg3.network.RetrofitClient;

import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class LoginActivity extends AppCompatActivity {
    private EditText emailEditText, passwordEditText;
    private Button loginButton;
    private TextView registerLink;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailEditText = findViewById(R.id.email);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);
        registerLink = findViewById(R.id.register_link);

        Retrofit retrofit = RetrofitClient.getClient("http://34.116.230.24:8001/");
        apiService = retrofit.create(ApiService.class);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        registerLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirigir a la URL de registro
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://34.116.230.24:8001/register"));
                startActivity(browserIntent);
            }
        });
    }

    private void login() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validación rápida de campos vacíos
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Introduce email y contraseña", Toast.LENGTH_SHORT).show();
            return;
        }

        Call<LoginResponse> call = apiService.login(email, password);
        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    String token = response.body().getAccessToken();

                    // Guardar token y email en SharedPreferences
                    SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("auth_token", token);
                    editor.putString("user_email", email); // guardar email para usarlo después
                    editor.apply();

                    // Redirigir a MainActivity
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    int code = response.code();
                    String serverMsg = null;

                    // Intentar extraer mensaje del cuerpo de error (p. ej. FastAPI devuelve {"detail": "..."} )
                    try {
                        if (response.errorBody() != null) {
                            String raw = response.errorBody().string();
                            if (raw != null && !raw.isEmpty()) {
                                JSONObject obj = new JSONObject(raw);
                                if (obj.has("detail")) {
                                    serverMsg = obj.get("detail").toString();
                                } else if (obj.has("message")) {
                                    serverMsg = obj.getString("message");
                                }
                            }
                        }
                    } catch (Exception ignored) { }

                    // Mostrar mensaje específico para credenciales incorrectas
                    if (code == 401 || code == 403 || code == 400 ||
                            (serverMsg != null && (
                                    serverMsg.toLowerCase().contains("incorrect") ||
                                            serverMsg.toLowerCase().contains("invalid") ||
                                            serverMsg.toLowerCase().contains("credencial") ||
                                            serverMsg.toLowerCase().contains("usuario") && serverMsg.toLowerCase().contains("contrase")
                            ))) {
                        Toast.makeText(LoginActivity.this, "Usuario o contraseña incorrecta", Toast.LENGTH_SHORT).show();
                    } else if (code == 422) {
                        Toast.makeText(LoginActivity.this, "Datos inválidos: revisa el email y la contraseña", Toast.LENGTH_SHORT).show();
                    } else if (code >= 500) {
                        Toast.makeText(LoginActivity.this, "Error del servidor. Inténtalo más tarde", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginActivity.this, "Error al iniciar sesión, inténtalo de nuevo", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Toast.makeText(LoginActivity.this, "Error de conexión: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
