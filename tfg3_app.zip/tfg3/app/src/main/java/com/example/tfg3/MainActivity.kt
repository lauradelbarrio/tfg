package com.example.tfg3

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.nfc.FormatException
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.NotificationCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import java.io.IOException
import java.nio.charset.Charset

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var actionBarDrawerToggle: ActionBarDrawerToggle
    private lateinit var navigationView: NavigationView

    private var nfcAdapter: NfcAdapter? = null
    private lateinit var pendingIntent: PendingIntent
    private lateinit var intentFiltersArray: Array<IntentFilter>
    private lateinit var techListsArray: Array<Array<String>>
    private lateinit var textViewInfo: TextView
    private lateinit var buttonWrite: Button
    private lateinit var buttonRead: Button
    private lateinit var editTextInput: EditText
    private var isWriteMode = false
    private var myTag: Tag? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedPreferences: SharedPreferences = getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE)
        val authToken = sharedPreferences.getString("auth_token", null)

        if (authToken == null) {
            // Si el token no está presente, redirigir a LoginActivity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        buttonWrite = findViewById(R.id.button_write)
        buttonRead = findViewById(R.id.button_read)
        editTextInput = findViewById(R.id.edit_text_input)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)

        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC no está soportado para este dispositivo", Toast.LENGTH_LONG).show()
            Log.e("NFC", "NFC no está soportado para este dispositivo")
            finish()
            return
        }

        if (!nfcAdapter!!.isEnabled) {
            Toast.makeText(this, "Habilita NFC en ajustes", Toast.LENGTH_LONG).show()
            Log.e("NFC", "NFC no está habilitado")
            startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
        }

        pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )

        val ndef = IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED).apply {
            try {
                addDataType("text/plain")
            } catch (e: IntentFilter.MalformedMimeTypeException) {
                // Error (excepción) al añadir el tipo MIME
                throw RuntimeException("fallo", e)
            }
        }
        val tagDiscovered = IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED)
        val techDiscovered = IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED)

        intentFiltersArray = arrayOf(ndef, tagDiscovered, techDiscovered)
        techListsArray = arrayOf(arrayOf(Ndef::class.java.name))

        buttonWrite.setOnClickListener {
            isWriteMode = true
            Toast.makeText(this, R.string.tap_to_write, Toast.LENGTH_SHORT).show()
            Log.i("NFC", "Write mode enabled")
        }

        buttonRead.setOnClickListener {
            isWriteMode = false
            Toast.makeText(this, R.string.tap_to_read, Toast.LENGTH_SHORT).show()
            Log.i("NFC", "Read mode enabled")
        }

        // Configuración del DrawerLayout
        drawerLayout = findViewById(R.id.drawer_layout)
        navigationView = findViewById(R.id.navigation_view)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        actionBarDrawerToggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close)
        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()

        navigationView.setNavigationItemSelectedListener(this)

        // Comprobar si la actividad fue iniciada desde una notificación
        val nfcContent = intent.getStringExtra("nfc_content")
        if (nfcContent != null) {
            textViewInfo.text = nfcContent
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        clearAuthToken()
    }

    private fun clearAuthToken() {
        val sharedPreferences: SharedPreferences = getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.remove("auth_token")
        editor.apply()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        Log.i("NFC", "New intent received with action: ${intent.action}")
        if (intent.action == NfcAdapter.ACTION_TAG_DISCOVERED ||
            intent.action == NfcAdapter.ACTION_NDEF_DISCOVERED ||
            intent.action == NfcAdapter.ACTION_TECH_DISCOVERED) {

            myTag = getTagFromIntent(intent)
            Log.i("NFC", "Tag discovered: $myTag")

            if (isWriteMode) {
                val originalText = editTextInput.text.toString()

                // Construimos la URL base a tu servidor, con la URL original como segmento codificado
                val baseUri = Uri.parse("http://34.175.150.36:8000/silence/redirect.html/${Uri.encode(originalText)}")

                // Obtenemos el email del usuario (guardado tras el login). Si no existe, no añadimos 'u'
                val prefs = getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE)
                val userEmail = prefs.getString("user_email", null)

                // Añadimos ?u=<email> solo si hay email y aún no existe el parámetro
                val uriToWrite = baseUri.buildUpon().apply {
                    if (!baseUri.getQueryParameterNames().contains("u") && !userEmail.isNullOrBlank()) {
                        appendQueryParameter("u", userEmail)
                    }
                }.build()

                val textToWrite = uriToWrite.toString()

                if (textToWrite.isEmpty()) {
                    Toast.makeText(this, "Introduzca un link o mensaje para escribir en su etiqueta", Toast.LENGTH_SHORT).show()
                    return
                }
                if (!textToWrite.startsWith("http://") && !textToWrite.startsWith("https://")) {
                    // Mensaje de error: URL inválida
                    Toast.makeText(this, "Introduce una URL válida que empiece por http:// o https://", Toast.LENGTH_SHORT).show()
                    return
                }

                val message = createNdefMessage(textToWrite)
                myTag?.let {
                    val result = writeNdefMessage(it, message)
                    if (result) {
                        Toast.makeText(this, "Escrito con éxito", Toast.LENGTH_SHORT).show()
                        Log.i("NFC", "Escrito con éxito: $textToWrite")
                    } else {
                        // Mensaje de error al escribir
                        Toast.makeText(this, "Error al escribir", Toast.LENGTH_SHORT).show()
                        Log.e("NFC", "Error al escribir")
                    }
                }
            } else {
                val ndef = Ndef.get(myTag)
                ndef?.let {
                    val ndefMessage = it.cachedNdefMessage
                    val records = ndefMessage.records
                    for (record in records) {
                        if (record.tnf == NdefRecord.TNF_WELL_KNOWN && record.type.contentEquals(NdefRecord.RTD_TEXT)) {
                            val payload = record.payload
                            val textEncoding = if ((payload[0].toInt() and 128) == 0) "UTF-8" else "UTF-16"
                            val languageCodeLength = payload[0].toInt() and 63

                            try {
                                val text = String(payload, languageCodeLength + 1, payload.size - languageCodeLength - 1, Charset.forName(textEncoding))
                                textViewInfo.text = getString(R.string.nfc_content, text)
                                Log.i("NFC", "Read content from NFC tag: $text")
                                if (text.startsWith("http://") || text.startsWith("https://")) {
                                    showNotification(this, text)
                                }
                            } catch (e: Exception) {
                                // Error de codificación no soportada
                                Log.e("NFC", "Codificación no soportada", e)
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        nfcAdapter?.enableForegroundDispatch(this, pendingIntent, intentFiltersArray, techListsArray)
        Log.i("NFC", "Foreground dispatch enabled")
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
        Log.i("NFC", "Foreground dispatch disabled")
    }

    private fun createNdefMessage(content: String): NdefMessage {
        val uriRecord = NdefRecord.createUri(Uri.parse(content))
        return NdefMessage(arrayOf(uriRecord))
    }

    private fun writeNdefMessage(tag: Tag, ndefMessage: NdefMessage): Boolean {
        return try {
            val ndef = Ndef.get(tag) ?: return false
            Log.i("NFC", "Connecting to tag")
            ndef.connect()
            if (!ndef.isWritable) {
                // Error: la etiqueta no es grabable
                Log.e("NFC", "La etiqueta no es grabable")
                Toast.makeText(this, "¡La etiqueta no es grabable!", Toast.LENGTH_SHORT).show()
                ndef.close()
                false
            } else {
                val size = ndefMessage.toByteArray().size
                if (ndef.maxSize < size) {
                    // Error: espacio insuficiente en la etiqueta
                    Log.e("NFC", "La etiqueta no tiene suficiente espacio")
                    Toast.makeText(this, "¡La etiqueta no tiene suficiente espacio!", Toast.LENGTH_SHORT).show()
                    ndef.close()
                    false
                } else {
                    ndef.writeNdefMessage(ndefMessage)
                    Log.i("NFC", "Message written successfully")
                    ndef.close()
                    true
                }
            }
        } catch (e: IOException) {
            // Error de E/S al escribir el mensaje NDEF
            Log.e("NFC", "IOException al escribir el mensaje NDEF", e)
            false
        } catch (e: FormatException) {
            // Error de formato al escribir el mensaje NDEF
            Log.e("NFC", "FormatException al escribir el mensaje NDEF", e)
            false
        }
    }

    private fun getTagFromIntent(intent: Intent): Tag? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
        }
    }

    private fun showNotification(context: Context, text: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "nfc_channel_id"
        val channelName = "NFC Channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "Channel for NFC notifications"
            channel.enableLights(true)
            channel.lightColor = Color.BLUE
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(text))
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(context, channelId)
            .setContentTitle("NFC Tag Detected")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(1, notification)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_write -> {
                drawerLayout.closeDrawer(GravityCompat.START)
                buttonWrite.performClick()
            }
            R.id.nav_buy -> {
                drawerLayout.closeDrawer(GravityCompat.START)
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://4a8195-2.myshopify.com/"))
                startActivity(browserIntent)
            }
        }
        return true
    }
}
